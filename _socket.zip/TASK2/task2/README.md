to complete task 2 

open 10 command prompts then run ```client.py```