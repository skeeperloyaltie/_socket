```for i in {1..10}; do python3 client.py < input.txt & done```
